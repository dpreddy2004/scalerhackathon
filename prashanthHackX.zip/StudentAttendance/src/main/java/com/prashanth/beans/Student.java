package com.prashanth.beans;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component
public class Student {

	private int studentID;
	private String lastName;
	private String firstName;
	private String presentOrAbsent;
	private String dateOfAttendance;

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getPresentOrAbsent() {
		return presentOrAbsent;
	}

	public void setPresentOrAbsent(String presentOrAbsent) {
		this.presentOrAbsent = presentOrAbsent;
	}

	public String getDateOfAttendance() {
		return dateOfAttendance;
	}

	public void setDateOfAttendance(String dateOfAttendance) {
		this.dateOfAttendance = dateOfAttendance;
	}

}
