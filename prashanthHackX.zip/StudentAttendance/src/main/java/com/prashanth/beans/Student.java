package com.prashanth.beans;

import org.springframework.stereotype.Component;

@Component
public class Student {

	private int StudentID;
	private String LastName;
	private String FirstName;
	private String PresentOrAbsent;
	private String DateOfAttendance;
	public int getStudentID() {
		return StudentID;
	}
	public void setStudentID(int studentID) {
		StudentID = studentID;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getPresentOrAbsent() {
		return PresentOrAbsent;
	}
	public void setPresentOrAbsent(String presentOrAbsent) {
		PresentOrAbsent = presentOrAbsent;
	}
	public String getDateOfAttendance() {
		return DateOfAttendance;
	}
	public void setDateOfAttendance(String dateOfAttendance) {
		DateOfAttendance = dateOfAttendance;
	}

	

}
