package com.prashanth.StudentAttendance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prashanth.beans.Student;
import com.prashanth.dao.StudentDao;

@Configuration
@ComponentScan("com.prashanth.dao")
@Controller   
public class StudentController {

	//private static final Logger log = LogFactory.getLog(StudentController.class);
 
    @Autowired    
    private StudentDao dao;//will inject dao from XML file  
    
        
    /*It displays a form to input data, here "command" is a reserved request attribute  
     *which is used to display object data into form  
     */    
    @RequestMapping("/studentform")    
    public String showform(Model m){    
        m.addAttribute("command", new Student());  
        return "studentform";   
    }    
    /*It saves object into database. The @ModelAttribute puts request data  
     *  into model object. You need to mention RequestMethod.POST method   
     *  because default request is GET*/    
    @RequestMapping(value="/save",method = RequestMethod.POST)    
    public String save(@ModelAttribute("student") Student student){    
        dao.save(student);    
        return "redirect:/viewstudent";//will redirect to viewstudent request mapping    
    }    
    /* It provides list of employees in model object */    
    @RequestMapping("/viewstudent")    
    public String viewemp(Model m){    
        List<Student> list=dao.getStudents();    
       // System.out.println("list = "+list.toString());
        m.addAttribute("list",list);  
        return "viewstudent";    
    }    
    /* It displays object data into form for the given id.   
     * The @PathVariable puts URL data into variable.*/    
    @RequestMapping(value="/editstudent/{id}")    
    public String edit(@PathVariable int id, Model m){    
    	Student emp=dao.geStudentById(id);    
        m.addAttribute("command",emp);  
        return "studenteditform";    
    }    
    /* It updates model object. */    
    @RequestMapping(value="/editsave",method = RequestMethod.POST)    
    public String editsave(@ModelAttribute("emp") Student emp){    
        dao.update(emp);    
        return "redirect:/viewstudent";    
    }    
    /* It deletes record for the given id in URL and redirects to /viewstudent */    
    @RequestMapping(value="/deletestudent/{id}",method = RequestMethod.GET)    
    public String delete(@PathVariable int id){    
        dao.delete(id);    
        return "redirect:/viewstudent";    
    }     
}